﻿namespace RubY
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.btnU2 = new System.Windows.Forms.Button();
            this.btnU = new System.Windows.Forms.Button();
            this.btnUprime = new System.Windows.Forms.Button();
            this.btnUw = new System.Windows.Forms.Button();
            this.btnDw = new System.Windows.Forms.Button();
            this.btnDprime = new System.Windows.Forms.Button();
            this.btnD = new System.Windows.Forms.Button();
            this.btnD2 = new System.Windows.Forms.Button();
            this.btnRw = new System.Windows.Forms.Button();
            this.btnRprime = new System.Windows.Forms.Button();
            this.btnR = new System.Windows.Forms.Button();
            this.btnR2 = new System.Windows.Forms.Button();
            this.btnLw = new System.Windows.Forms.Button();
            this.btnLprime = new System.Windows.Forms.Button();
            this.btnL = new System.Windows.Forms.Button();
            this.btnL2 = new System.Windows.Forms.Button();
            this.btnFw = new System.Windows.Forms.Button();
            this.btnFprime = new System.Windows.Forms.Button();
            this.btnF = new System.Windows.Forms.Button();
            this.btnF2 = new System.Windows.Forms.Button();
            this.btnBw = new System.Windows.Forms.Button();
            this.btnBprime = new System.Windows.Forms.Button();
            this.btnB = new System.Windows.Forms.Button();
            this.btnB2 = new System.Windows.Forms.Button();
            this.btnxprime = new System.Windows.Forms.Button();
            this.btnx = new System.Windows.Forms.Button();
            this.btnx2 = new System.Windows.Forms.Button();
            this.btnyprime = new System.Windows.Forms.Button();
            this.btny = new System.Windows.Forms.Button();
            this.btny2 = new System.Windows.Forms.Button();
            this.btnzprime = new System.Windows.Forms.Button();
            this.btnz = new System.Windows.Forms.Button();
            this.btnz2 = new System.Windows.Forms.Button();
            this.btnMprime = new System.Windows.Forms.Button();
            this.btnM = new System.Windows.Forms.Button();
            this.btnM2 = new System.Windows.Forms.Button();
            this.btnEprime = new System.Windows.Forms.Button();
            this.btnE = new System.Windows.Forms.Button();
            this.btnE2 = new System.Windows.Forms.Button();
            this.btnSprime = new System.Windows.Forms.Button();
            this.btnS = new System.Windows.Forms.Button();
            this.btnS2 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.btnScramble = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            this.SuspendLayout();
            // 
            // imageList1
            // 
            this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageList1.ImageSize = new System.Drawing.Size(16, 16);
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // btnU2
            // 
            this.btnU2.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnU2.Location = new System.Drawing.Point(533, 151);
            this.btnU2.Name = "btnU2";
            this.btnU2.Size = new System.Drawing.Size(60, 28);
            this.btnU2.TabIndex = 0;
            this.btnU2.Text = "U2";
            this.btnU2.UseVisualStyleBackColor = true;
            this.btnU2.Click += new System.EventHandler(this.btnU2_Click);
            // 
            // btnU
            // 
            this.btnU.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnU.Location = new System.Drawing.Point(533, 89);
            this.btnU.Name = "btnU";
            this.btnU.Size = new System.Drawing.Size(60, 29);
            this.btnU.TabIndex = 1;
            this.btnU.Text = "U";
            this.btnU.UseVisualStyleBackColor = true;
            this.btnU.Click += new System.EventHandler(this.btnU_Click);
            // 
            // btnUprime
            // 
            this.btnUprime.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUprime.Location = new System.Drawing.Point(533, 120);
            this.btnUprime.Name = "btnUprime";
            this.btnUprime.Size = new System.Drawing.Size(60, 29);
            this.btnUprime.TabIndex = 2;
            this.btnUprime.Text = "U\'";
            this.btnUprime.UseVisualStyleBackColor = true;
            this.btnUprime.Click += new System.EventHandler(this.btnUprime_Click);
            // 
            // btnUw
            // 
            this.btnUw.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUw.Location = new System.Drawing.Point(533, 181);
            this.btnUw.Name = "btnUw";
            this.btnUw.Size = new System.Drawing.Size(60, 27);
            this.btnUw.TabIndex = 3;
            this.btnUw.Text = "u";
            this.btnUw.UseVisualStyleBackColor = true;
            this.btnUw.Click += new System.EventHandler(this.btnUw_Click);
            // 
            // btnDw
            // 
            this.btnDw.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDw.Location = new System.Drawing.Point(615, 181);
            this.btnDw.Name = "btnDw";
            this.btnDw.Size = new System.Drawing.Size(60, 27);
            this.btnDw.TabIndex = 10;
            this.btnDw.Text = "d";
            this.btnDw.UseVisualStyleBackColor = true;
            this.btnDw.Click += new System.EventHandler(this.btnDw_Click);
            // 
            // btnDprime
            // 
            this.btnDprime.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDprime.Location = new System.Drawing.Point(615, 120);
            this.btnDprime.Name = "btnDprime";
            this.btnDprime.Size = new System.Drawing.Size(60, 29);
            this.btnDprime.TabIndex = 9;
            this.btnDprime.Text = "D\'";
            this.btnDprime.UseVisualStyleBackColor = true;
            this.btnDprime.Click += new System.EventHandler(this.btnDprime_Click);
            // 
            // btnD
            // 
            this.btnD.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnD.Location = new System.Drawing.Point(615, 89);
            this.btnD.Name = "btnD";
            this.btnD.Size = new System.Drawing.Size(60, 29);
            this.btnD.TabIndex = 8;
            this.btnD.Text = "D";
            this.btnD.UseVisualStyleBackColor = true;
            this.btnD.Click += new System.EventHandler(this.btnD_Click);
            // 
            // btnD2
            // 
            this.btnD2.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnD2.Location = new System.Drawing.Point(615, 151);
            this.btnD2.Name = "btnD2";
            this.btnD2.Size = new System.Drawing.Size(60, 28);
            this.btnD2.TabIndex = 7;
            this.btnD2.Text = "D2";
            this.btnD2.UseVisualStyleBackColor = true;
            this.btnD2.Click += new System.EventHandler(this.btnD2_Click);
            // 
            // btnRw
            // 
            this.btnRw.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRw.Location = new System.Drawing.Point(697, 181);
            this.btnRw.Name = "btnRw";
            this.btnRw.Size = new System.Drawing.Size(60, 27);
            this.btnRw.TabIndex = 14;
            this.btnRw.Text = "r";
            this.btnRw.UseVisualStyleBackColor = true;
            this.btnRw.Click += new System.EventHandler(this.btnRw_Click);
            // 
            // btnRprime
            // 
            this.btnRprime.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRprime.Location = new System.Drawing.Point(697, 120);
            this.btnRprime.Name = "btnRprime";
            this.btnRprime.Size = new System.Drawing.Size(60, 29);
            this.btnRprime.TabIndex = 13;
            this.btnRprime.Text = "R\'";
            this.btnRprime.UseVisualStyleBackColor = true;
            this.btnRprime.Click += new System.EventHandler(this.btnRprime_Click);
            // 
            // btnR
            // 
            this.btnR.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnR.Location = new System.Drawing.Point(697, 89);
            this.btnR.Name = "btnR";
            this.btnR.Size = new System.Drawing.Size(60, 29);
            this.btnR.TabIndex = 12;
            this.btnR.Text = "R";
            this.btnR.UseVisualStyleBackColor = true;
            this.btnR.Click += new System.EventHandler(this.btnR_Click);
            // 
            // btnR2
            // 
            this.btnR2.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnR2.Location = new System.Drawing.Point(697, 151);
            this.btnR2.Name = "btnR2";
            this.btnR2.Size = new System.Drawing.Size(60, 28);
            this.btnR2.TabIndex = 11;
            this.btnR2.Text = "R2";
            this.btnR2.UseVisualStyleBackColor = true;
            this.btnR2.Click += new System.EventHandler(this.btnR2_Click);
            // 
            // btnLw
            // 
            this.btnLw.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLw.Location = new System.Drawing.Point(777, 181);
            this.btnLw.Name = "btnLw";
            this.btnLw.Size = new System.Drawing.Size(60, 27);
            this.btnLw.TabIndex = 18;
            this.btnLw.Text = "l";
            this.btnLw.UseVisualStyleBackColor = true;
            this.btnLw.Click += new System.EventHandler(this.btnLw_Click);
            // 
            // btnLprime
            // 
            this.btnLprime.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLprime.Location = new System.Drawing.Point(777, 120);
            this.btnLprime.Name = "btnLprime";
            this.btnLprime.Size = new System.Drawing.Size(60, 29);
            this.btnLprime.TabIndex = 17;
            this.btnLprime.Text = "L\'";
            this.btnLprime.UseVisualStyleBackColor = true;
            this.btnLprime.Click += new System.EventHandler(this.btnLprime_Click);
            // 
            // btnL
            // 
            this.btnL.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnL.Location = new System.Drawing.Point(777, 89);
            this.btnL.Name = "btnL";
            this.btnL.Size = new System.Drawing.Size(60, 29);
            this.btnL.TabIndex = 16;
            this.btnL.Text = "L";
            this.btnL.UseVisualStyleBackColor = true;
            this.btnL.Click += new System.EventHandler(this.btnL_Click);
            // 
            // btnL2
            // 
            this.btnL2.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnL2.Location = new System.Drawing.Point(777, 151);
            this.btnL2.Name = "btnL2";
            this.btnL2.Size = new System.Drawing.Size(60, 28);
            this.btnL2.TabIndex = 15;
            this.btnL2.Text = "L2";
            this.btnL2.UseVisualStyleBackColor = true;
            this.btnL2.Click += new System.EventHandler(this.btnL2_Click);
            // 
            // btnFw
            // 
            this.btnFw.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFw.Location = new System.Drawing.Point(853, 181);
            this.btnFw.Name = "btnFw";
            this.btnFw.Size = new System.Drawing.Size(60, 27);
            this.btnFw.TabIndex = 22;
            this.btnFw.Text = "f";
            this.btnFw.UseVisualStyleBackColor = true;
            this.btnFw.Click += new System.EventHandler(this.btnFw_Click);
            // 
            // btnFprime
            // 
            this.btnFprime.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFprime.Location = new System.Drawing.Point(853, 120);
            this.btnFprime.Name = "btnFprime";
            this.btnFprime.Size = new System.Drawing.Size(60, 29);
            this.btnFprime.TabIndex = 21;
            this.btnFprime.Text = "F\'";
            this.btnFprime.UseVisualStyleBackColor = true;
            this.btnFprime.Click += new System.EventHandler(this.btnFprime_Click);
            // 
            // btnF
            // 
            this.btnF.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnF.Location = new System.Drawing.Point(853, 89);
            this.btnF.Name = "btnF";
            this.btnF.Size = new System.Drawing.Size(60, 29);
            this.btnF.TabIndex = 20;
            this.btnF.Text = "F";
            this.btnF.UseVisualStyleBackColor = true;
            this.btnF.Click += new System.EventHandler(this.btnF_Click);
            // 
            // btnF2
            // 
            this.btnF2.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnF2.Location = new System.Drawing.Point(853, 151);
            this.btnF2.Name = "btnF2";
            this.btnF2.Size = new System.Drawing.Size(60, 28);
            this.btnF2.TabIndex = 19;
            this.btnF2.Text = "F2";
            this.btnF2.UseVisualStyleBackColor = true;
            this.btnF2.Click += new System.EventHandler(this.btnF2_Click);
            // 
            // btnBw
            // 
            this.btnBw.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBw.Location = new System.Drawing.Point(927, 181);
            this.btnBw.Name = "btnBw";
            this.btnBw.Size = new System.Drawing.Size(60, 27);
            this.btnBw.TabIndex = 26;
            this.btnBw.Text = "b";
            this.btnBw.UseVisualStyleBackColor = true;
            this.btnBw.Click += new System.EventHandler(this.btnBw_Click);
            // 
            // btnBprime
            // 
            this.btnBprime.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBprime.Location = new System.Drawing.Point(927, 120);
            this.btnBprime.Name = "btnBprime";
            this.btnBprime.Size = new System.Drawing.Size(60, 29);
            this.btnBprime.TabIndex = 25;
            this.btnBprime.Text = "B\'";
            this.btnBprime.UseVisualStyleBackColor = true;
            this.btnBprime.Click += new System.EventHandler(this.btnBprime_Click);
            // 
            // btnB
            // 
            this.btnB.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnB.Location = new System.Drawing.Point(927, 89);
            this.btnB.Name = "btnB";
            this.btnB.Size = new System.Drawing.Size(60, 29);
            this.btnB.TabIndex = 24;
            this.btnB.Text = "B";
            this.btnB.UseVisualStyleBackColor = true;
            this.btnB.Click += new System.EventHandler(this.btnB_Click);
            // 
            // btnB2
            // 
            this.btnB2.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnB2.Location = new System.Drawing.Point(927, 151);
            this.btnB2.Name = "btnB2";
            this.btnB2.Size = new System.Drawing.Size(60, 28);
            this.btnB2.TabIndex = 23;
            this.btnB2.Text = "B2";
            this.btnB2.UseVisualStyleBackColor = true;
            this.btnB2.Click += new System.EventHandler(this.btnB2_Click);
            // 
            // btnxprime
            // 
            this.btnxprime.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnxprime.Location = new System.Drawing.Point(777, 331);
            this.btnxprime.Name = "btnxprime";
            this.btnxprime.Size = new System.Drawing.Size(60, 27);
            this.btnxprime.TabIndex = 29;
            this.btnxprime.Text = "x\'";
            this.btnxprime.UseVisualStyleBackColor = true;
            this.btnxprime.Click += new System.EventHandler(this.btnxprime_Click);
            // 
            // btnx
            // 
            this.btnx.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnx.Location = new System.Drawing.Point(777, 301);
            this.btnx.Name = "btnx";
            this.btnx.Size = new System.Drawing.Size(60, 27);
            this.btnx.TabIndex = 28;
            this.btnx.Text = "x";
            this.btnx.UseVisualStyleBackColor = true;
            this.btnx.Click += new System.EventHandler(this.btnx_Click);
            // 
            // btnx2
            // 
            this.btnx2.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnx2.Location = new System.Drawing.Point(777, 362);
            this.btnx2.Name = "btnx2";
            this.btnx2.Size = new System.Drawing.Size(60, 27);
            this.btnx2.TabIndex = 27;
            this.btnx2.Text = "x2";
            this.btnx2.UseVisualStyleBackColor = true;
            this.btnx2.Click += new System.EventHandler(this.btnx2_Click);
            // 
            // btnyprime
            // 
            this.btnyprime.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnyprime.Location = new System.Drawing.Point(853, 331);
            this.btnyprime.Name = "btnyprime";
            this.btnyprime.Size = new System.Drawing.Size(60, 27);
            this.btnyprime.TabIndex = 32;
            this.btnyprime.Text = "y\'";
            this.btnyprime.UseVisualStyleBackColor = true;
            this.btnyprime.Click += new System.EventHandler(this.btnyprime_Click);
            // 
            // btny
            // 
            this.btny.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btny.Location = new System.Drawing.Point(853, 301);
            this.btny.Name = "btny";
            this.btny.Size = new System.Drawing.Size(60, 27);
            this.btny.TabIndex = 31;
            this.btny.Text = "y";
            this.btny.UseVisualStyleBackColor = true;
            this.btny.Click += new System.EventHandler(this.btny_Click);
            // 
            // btny2
            // 
            this.btny2.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btny2.Location = new System.Drawing.Point(853, 362);
            this.btny2.Name = "btny2";
            this.btny2.Size = new System.Drawing.Size(60, 27);
            this.btny2.TabIndex = 30;
            this.btny2.Text = "y2";
            this.btny2.UseVisualStyleBackColor = true;
            this.btny2.Click += new System.EventHandler(this.btny2_Click);
            // 
            // btnzprime
            // 
            this.btnzprime.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnzprime.Location = new System.Drawing.Point(927, 331);
            this.btnzprime.Name = "btnzprime";
            this.btnzprime.Size = new System.Drawing.Size(60, 27);
            this.btnzprime.TabIndex = 35;
            this.btnzprime.Text = "z\'";
            this.btnzprime.UseVisualStyleBackColor = true;
            this.btnzprime.Click += new System.EventHandler(this.btnzprime_Click);
            // 
            // btnz
            // 
            this.btnz.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnz.Location = new System.Drawing.Point(927, 301);
            this.btnz.Name = "btnz";
            this.btnz.Size = new System.Drawing.Size(60, 27);
            this.btnz.TabIndex = 34;
            this.btnz.Text = "z";
            this.btnz.UseVisualStyleBackColor = true;
            this.btnz.Click += new System.EventHandler(this.btnz_Click);
            // 
            // btnz2
            // 
            this.btnz2.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnz2.Location = new System.Drawing.Point(927, 362);
            this.btnz2.Name = "btnz2";
            this.btnz2.Size = new System.Drawing.Size(60, 27);
            this.btnz2.TabIndex = 33;
            this.btnz2.Text = "z2";
            this.btnz2.UseVisualStyleBackColor = true;
            this.btnz2.Click += new System.EventHandler(this.btnz2_Click);
            // 
            // btnMprime
            // 
            this.btnMprime.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMprime.Location = new System.Drawing.Point(533, 333);
            this.btnMprime.Name = "btnMprime";
            this.btnMprime.Size = new System.Drawing.Size(60, 29);
            this.btnMprime.TabIndex = 38;
            this.btnMprime.Text = "M\'";
            this.btnMprime.UseVisualStyleBackColor = true;
            this.btnMprime.Click += new System.EventHandler(this.btnMprime_Click);
            // 
            // btnM
            // 
            this.btnM.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnM.Location = new System.Drawing.Point(533, 301);
            this.btnM.Name = "btnM";
            this.btnM.Size = new System.Drawing.Size(60, 29);
            this.btnM.TabIndex = 37;
            this.btnM.Text = "M";
            this.btnM.UseVisualStyleBackColor = true;
            this.btnM.Click += new System.EventHandler(this.btnM_Click);
            // 
            // btnM2
            // 
            this.btnM2.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnM2.Location = new System.Drawing.Point(534, 364);
            this.btnM2.Name = "btnM2";
            this.btnM2.Size = new System.Drawing.Size(60, 29);
            this.btnM2.TabIndex = 36;
            this.btnM2.Text = "M2";
            this.btnM2.UseVisualStyleBackColor = true;
            this.btnM2.Click += new System.EventHandler(this.btnM2_Click);
            // 
            // btnEprime
            // 
            this.btnEprime.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEprime.Location = new System.Drawing.Point(615, 332);
            this.btnEprime.Name = "btnEprime";
            this.btnEprime.Size = new System.Drawing.Size(60, 27);
            this.btnEprime.TabIndex = 41;
            this.btnEprime.Text = "E\'";
            this.btnEprime.UseVisualStyleBackColor = true;
            this.btnEprime.Click += new System.EventHandler(this.btnEprime_Click);
            // 
            // btnE
            // 
            this.btnE.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnE.Location = new System.Drawing.Point(615, 301);
            this.btnE.Name = "btnE";
            this.btnE.Size = new System.Drawing.Size(60, 27);
            this.btnE.TabIndex = 40;
            this.btnE.Text = "E";
            this.btnE.UseVisualStyleBackColor = true;
            this.btnE.Click += new System.EventHandler(this.btnE_Click);
            // 
            // btnE2
            // 
            this.btnE2.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnE2.Location = new System.Drawing.Point(615, 362);
            this.btnE2.Name = "btnE2";
            this.btnE2.Size = new System.Drawing.Size(60, 27);
            this.btnE2.TabIndex = 39;
            this.btnE2.Text = "E2";
            this.btnE2.UseVisualStyleBackColor = true;
            this.btnE2.Click += new System.EventHandler(this.btnE2_Click);
            // 
            // btnSprime
            // 
            this.btnSprime.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSprime.Location = new System.Drawing.Point(697, 332);
            this.btnSprime.Name = "btnSprime";
            this.btnSprime.Size = new System.Drawing.Size(60, 27);
            this.btnSprime.TabIndex = 44;
            this.btnSprime.Text = "S\'";
            this.btnSprime.UseVisualStyleBackColor = true;
            this.btnSprime.Click += new System.EventHandler(this.btnSprime_Click);
            // 
            // btnS
            // 
            this.btnS.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnS.Location = new System.Drawing.Point(697, 301);
            this.btnS.Name = "btnS";
            this.btnS.Size = new System.Drawing.Size(60, 27);
            this.btnS.TabIndex = 43;
            this.btnS.Text = "S";
            this.btnS.UseVisualStyleBackColor = true;
            this.btnS.Click += new System.EventHandler(this.btnS_Click);
            // 
            // btnS2
            // 
            this.btnS2.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnS2.Location = new System.Drawing.Point(697, 362);
            this.btnS2.Name = "btnS2";
            this.btnS2.Size = new System.Drawing.Size(60, 27);
            this.btnS2.TabIndex = 42;
            this.btnS2.Text = "S2";
            this.btnS2.UseVisualStyleBackColor = true;
            this.btnS2.Click += new System.EventHandler(this.btnS2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(533, 23);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(60, 60);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 45;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(615, 23);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(60, 60);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 46;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(697, 23);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(60, 60);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 47;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(777, 23);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(60, 60);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 48;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(853, 23);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(60, 60);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 49;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(927, 23);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(60, 60);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 50;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7.Image")));
            this.pictureBox7.Location = new System.Drawing.Point(927, 235);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(60, 60);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 56;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox8.Image")));
            this.pictureBox8.Location = new System.Drawing.Point(853, 235);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(60, 60);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 55;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox9.Image")));
            this.pictureBox9.Location = new System.Drawing.Point(777, 235);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(60, 60);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9.TabIndex = 54;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox10.Image")));
            this.pictureBox10.Location = new System.Drawing.Point(697, 235);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(60, 60);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox10.TabIndex = 53;
            this.pictureBox10.TabStop = false;
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox11.Image")));
            this.pictureBox11.Location = new System.Drawing.Point(615, 235);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(60, 60);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox11.TabIndex = 52;
            this.pictureBox11.TabStop = false;
            // 
            // pictureBox12
            // 
            this.pictureBox12.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox12.Image")));
            this.pictureBox12.Location = new System.Drawing.Point(533, 235);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(60, 60);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox12.TabIndex = 51;
            this.pictureBox12.TabStop = false;
            // 
            // btnScramble
            // 
            this.btnScramble.Location = new System.Drawing.Point(145, 370);
            this.btnScramble.Name = "btnScramble";
            this.btnScramble.Size = new System.Drawing.Size(75, 23);
            this.btnScramble.TabIndex = 57;
            this.btnScramble.Text = "Scramble";
            this.btnScramble.UseVisualStyleBackColor = true;
            this.btnScramble.Click += new System.EventHandler(this.btnScramble_Click);
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(226, 370);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(75, 23);
            this.btnReset.TabIndex = 58;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1013, 450);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnScramble);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.pictureBox8);
            this.Controls.Add(this.pictureBox9);
            this.Controls.Add(this.pictureBox10);
            this.Controls.Add(this.pictureBox11);
            this.Controls.Add(this.pictureBox12);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnSprime);
            this.Controls.Add(this.btnS);
            this.Controls.Add(this.btnS2);
            this.Controls.Add(this.btnEprime);
            this.Controls.Add(this.btnE);
            this.Controls.Add(this.btnE2);
            this.Controls.Add(this.btnMprime);
            this.Controls.Add(this.btnM);
            this.Controls.Add(this.btnM2);
            this.Controls.Add(this.btnzprime);
            this.Controls.Add(this.btnz);
            this.Controls.Add(this.btnz2);
            this.Controls.Add(this.btnyprime);
            this.Controls.Add(this.btny);
            this.Controls.Add(this.btny2);
            this.Controls.Add(this.btnxprime);
            this.Controls.Add(this.btnx);
            this.Controls.Add(this.btnx2);
            this.Controls.Add(this.btnBw);
            this.Controls.Add(this.btnBprime);
            this.Controls.Add(this.btnB);
            this.Controls.Add(this.btnB2);
            this.Controls.Add(this.btnFw);
            this.Controls.Add(this.btnFprime);
            this.Controls.Add(this.btnF);
            this.Controls.Add(this.btnF2);
            this.Controls.Add(this.btnLw);
            this.Controls.Add(this.btnLprime);
            this.Controls.Add(this.btnL);
            this.Controls.Add(this.btnL2);
            this.Controls.Add(this.btnRw);
            this.Controls.Add(this.btnRprime);
            this.Controls.Add(this.btnR);
            this.Controls.Add(this.btnR2);
            this.Controls.Add(this.btnDw);
            this.Controls.Add(this.btnDprime);
            this.Controls.Add(this.btnD);
            this.Controls.Add(this.btnD2);
            this.Controls.Add(this.btnUw);
            this.Controls.Add(this.btnUprime);
            this.Controls.Add(this.btnU);
            this.Controls.Add(this.btnU2);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Button btnU2;
        private System.Windows.Forms.Button btnU;
        private System.Windows.Forms.Button btnUprime;
        private System.Windows.Forms.Button btnUw;
        private System.Windows.Forms.Button btnDw;
        private System.Windows.Forms.Button btnDprime;
        private System.Windows.Forms.Button btnD;
        private System.Windows.Forms.Button btnD2;
        private System.Windows.Forms.Button btnRw;
        private System.Windows.Forms.Button btnRprime;
        private System.Windows.Forms.Button btnR;
        private System.Windows.Forms.Button btnR2;
        private System.Windows.Forms.Button btnLw;
        private System.Windows.Forms.Button btnLprime;
        private System.Windows.Forms.Button btnL;
        private System.Windows.Forms.Button btnL2;
        private System.Windows.Forms.Button btnFw;
        private System.Windows.Forms.Button btnFprime;
        private System.Windows.Forms.Button btnF;
        private System.Windows.Forms.Button btnF2;
        private System.Windows.Forms.Button btnBw;
        private System.Windows.Forms.Button btnBprime;
        private System.Windows.Forms.Button btnB;
        private System.Windows.Forms.Button btnB2;
        private System.Windows.Forms.Button btnxprime;
        private System.Windows.Forms.Button btnx;
        private System.Windows.Forms.Button btnx2;
        private System.Windows.Forms.Button btnyprime;
        private System.Windows.Forms.Button btny;
        private System.Windows.Forms.Button btny2;
        private System.Windows.Forms.Button btnzprime;
        private System.Windows.Forms.Button btnz;
        private System.Windows.Forms.Button btnz2;
        private System.Windows.Forms.Button btnMprime;
        private System.Windows.Forms.Button btnM;
        private System.Windows.Forms.Button btnM2;
        private System.Windows.Forms.Button btnEprime;
        private System.Windows.Forms.Button btnE;
        private System.Windows.Forms.Button btnE2;
        private System.Windows.Forms.Button btnSprime;
        private System.Windows.Forms.Button btnS;
        private System.Windows.Forms.Button btnS2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.Button btnScramble;
        private System.Windows.Forms.Button btnReset;
    }
}


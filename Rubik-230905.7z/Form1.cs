﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlTypes;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GAN;
using LibGrilleDeJeu;

namespace RubY
{
    public partial class Form1 : Form
    {
        private Grille grid;

        private Dictionary<string, List<int>> plane = new Dictionary<string, List<int>> {
            {
                "UP",
                new List<int> {0,3}
            },
            {
                "DOWN",
                new List<int> {6,3}
            },
            {
                "LEFT",
                new List<int> {3,0}
            },
            {
                "RIGHT",
                new List<int> {3,6}
            },
            {
                "FRONT",
                new List<int> {3,3}
            },
            {
                "BACK",
                new List<int> {3,9}
            },
        };

        private List<List<int>> startErase = new List<List<int>>()
        {
            new List<int> {0, 0},
            new List<int> {0, 6},
            new List<int> {6,0},
            new List<int> {6,6},
            new List<int> {9,0},
            new List<int> {9,6}

        };

        public Form1()
        {
            InitializeComponent();
            Case.Controls = this.Controls;
            Case.Location = new Point(30, 30);
            grid = new Grille(12, 9, TypeCase.Button, System.Drawing.Color.White, imageList1);
            grid.UserInteraction += ActionSurLaCase;

            foreach(List<int> list in startErase)
            {
                for (int i = 0; i < 3; i++)
                {
                    for (int j = 0; j < 3; j++)
                    {
                        grid.getCase(list[0] + i, list[1] + j).CaseType = TypeCase.PictureBox;
                    }
                }
            }
            Fill();
        }

        private void ActionSurLaCase(Interaction interaction, TypeCase typeCase, Case sender, string name)
        {
            
        }

        private void Update(string face, int x, int y, System.Drawing.Color new_val)
        {
            grid.getCase(plane[face][1] + x, plane[face][0] + y).BackColor = new_val;
        }

        private void Fill()
        {
            for(int i = 0;i < 3;i++)
            {
                for(int j = 0;j < 3; j++)
                {
                    Update("LEFT", i, j, System.Drawing.Color.Orange);
                }
            }

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Update("UP", i, j, System.Drawing.Color.White);
                }
            }

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Update("RIGHT", i, j, System.Drawing.Color.Red);
                }
            }

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Update("DOWN", i, j, System.Drawing.Color.Yellow);
                }
            }

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Update("BACK", i, j, System.Drawing.Color.Blue);
                }
            }

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Update("FRONT", i, j, System.Drawing.Color.Green);
                }
            }
        }

        private void btnU_Click(object sender, EventArgs e)
        {

        }

        private void btnUprime_Click(object sender, EventArgs e)
        {

        }

        private void btnU2_Click(object sender, EventArgs e)
        {

        }

        private void btnUw_Click(object sender, EventArgs e)
        {

        }

        private void btnD_Click(object sender, EventArgs e)
        {

        }

        private void btnDprime_Click(object sender, EventArgs e)
        {

        }

        private void btnD2_Click(object sender, EventArgs e)
        {

        }

        private void btnDw_Click(object sender, EventArgs e)
        {

        }

        private void btnR_Click(object sender, EventArgs e)
        {

        }

        private void btnRprime_Click(object sender, EventArgs e)
        {

        }

        private void btnR2_Click(object sender, EventArgs e)
        {

        }

        private void btnRw_Click(object sender, EventArgs e)
        {

        }

        private void btnL_Click(object sender, EventArgs e)
        {

        }

        private void btnLprime_Click(object sender, EventArgs e)
        {

        }

        private void btnL2_Click(object sender, EventArgs e)
        {

        }

        private void btnLw_Click(object sender, EventArgs e)
        {

        }

        private void btnF_Click(object sender, EventArgs e)
        {

        }

        private void btnFprime_Click(object sender, EventArgs e)
        {

        }

        private void btnF2_Click(object sender, EventArgs e)
        {

        }

        private void btnFw_Click(object sender, EventArgs e)
        {

        }

        private void btnB_Click(object sender, EventArgs e)
        {

        }

        private void btnBprime_Click(object sender, EventArgs e)
        {

        }

        private void btnB2_Click(object sender, EventArgs e)
        {

        }

        private void btnBw_Click(object sender, EventArgs e)
        {

        }

        private void btnM_Click(object sender, EventArgs e)
        {

        }

        private void btnMprime_Click(object sender, EventArgs e)
        {

        }

        private void btnM2_Click(object sender, EventArgs e)
        {

        }

        private void btnE_Click(object sender, EventArgs e)
        {

        }

        private void btnEprime_Click(object sender, EventArgs e)
        {

        }

        private void btnE2_Click(object sender, EventArgs e)
        {

        }

        private void btnS_Click(object sender, EventArgs e)
        {

        }

        private void btnSprime_Click(object sender, EventArgs e)
        {

        }

        private void btnS2_Click(object sender, EventArgs e)
        {

        }

        private void btnx_Click(object sender, EventArgs e)
        {

        }

        private void btnxprime_Click(object sender, EventArgs e)
        {

        }

        private void btnx2_Click(object sender, EventArgs e)
        {

        }

        private void btny_Click(object sender, EventArgs e)
        {

        }

        private void btnyprime_Click(object sender, EventArgs e)
        {

        }

        private void btny2_Click(object sender, EventArgs e)
        {

        }

        private void btnz_Click(object sender, EventArgs e)
        {

        }

        private void btnzprime_Click(object sender, EventArgs e)
        {

        }

        private void btnz2_Click(object sender, EventArgs e)
        {

        }

        private void btnScramble_Click(object sender, EventArgs e)
        {

        }

        private void btnReset_Click(object sender, EventArgs e)
        {

        }
    }
}
